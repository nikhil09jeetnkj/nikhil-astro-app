const withPWA = (config) => config;
module.exports = withPWA({reactStrictMode: true});
